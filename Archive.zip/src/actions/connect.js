import { connect } from 'react-redux';
import { bindActionCreators} from 'redux';
import App from '../App';
import * as AllAction from '../actions/actionCreator';

function mapStateToProps(store) {
    return {
        add: store.add,
        remove: store.remove
    }
}

function mapDispatchToProps(dispatch) {
    return bindActionCreators(AllAction, dispatch);
}

const MainApp = connect(mapStateToProps, mapDispatchToProps);

export default MainApp;