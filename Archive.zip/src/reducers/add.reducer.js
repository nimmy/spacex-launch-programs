export function add(defaultStore = {}, action) {
    switch(action.type) {
        case 'ADD':
        return [...defaultStore, action.item];

        default:
            return defaultStore;
    }
}