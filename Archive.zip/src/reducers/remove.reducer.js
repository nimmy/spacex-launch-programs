export function remove(defaultStore = {}, action) {
    switch(action.type) {
        case 'REMOVE':
        return [...defaultStore, action.item];

        default:
            return defaultStore;
    }
}