import { combineReducers } from 'redux';
import { add } from  './add.reducer';
import { remove } from  './remove.reducer';

const rootReducer = combineReducers({add, remove});
export default rootReducer;