import React, {useState, useEffect} from 'react';
import axios from 'axios';

export const Thumbnail = () => {
    const [allThumbnail, setallThumbnail] = useState([]);
    let getAllThumb;
    useEffect(() => {
        let limit = 100;
        let urlString = `https://api.spaceXdata.com/v3/launches?limit=${limit}`;
        axios
            .get(urlString)
            .then((response) => {
                localStorage.setItem('retrievedObject', JSON.stringify(response.data)); 
                setallThumbnail(response.data)
            });
    },[]);
    
    let storedObject = localStorage.getItem('retrievedObject');

    getAllThumb = allThumbnail.map((thumb) => {
        
        return <div className="col-sm-1 col-md-6 col-lg-3 col-xl-3" key={thumb.flight_number}>
            <div className="card m-1 mt-4">
                <div className="img-wrapper alert-secondary"><img width="100px" src={thumb.links.mission_patch_small} className="card-img-top" alt={thumb.mission_name} /></div>
                <div className="card-body">
                    <h6 className="card-title">{thumb.mission_name}#{thumb.flight_number}</h6>
                    <p className="card-text"><strong>Launch Year -</strong> {thumb.launch_year}</p>
                    <p className="card-text"><strong>Successful Launch -</strong> {thumb.launch_success ? <span className="badge bg-success">True</span> : <span className="badge bg-danger">false</span>}</p>
                    <p className="card-text"><strong>Successful Landing -</strong> {thumb.rocket.first_stage.cores[0].land_success !== null ? <span className="badge alert-success">Successful</span> : <span className="badge alert-danger">Fail</span> }</p>
                </div>
            </div>
        </div>
    })

    let startYear = 2006;
    let yearLoop = [];
    
    for (let i = 0; i < 15; i++) {
        yearLoop.push(startYear+i);
    }

    let filteredData = [];
    function getYearData(e, data) {
        JSON.parse(storedObject).map((item) =>  {
            Object.keys(item).forEach(function (parseData) {
                if ((parseData ===  'launch_year' && item[parseData]  ==  data) || (parseData ===  'launch_success' && item[parseData]  ==  data)) {
                    filteredData.push(item);
                }
            });
        });
        setallThumbnail(filteredData);
    }

    let launch_year = yearLoop.map(function(year) {
        return <div className="col-6 d-grid gap-2 mt-2" key={year}>
            <button type="button" className="btn btn-info" onClick={(event) => getYearData(event, year)}>{year}</button>
        </div>
    });

    return (
        <div className="container">
            <div className="row">
                <div className="col-sm-1 col-md-2 col-lg-2 col-xl-2 mt-3">
                    <h4><strong>Filters</strong></h4>
                    <div className="heading"><strong><i className="bi bi-broadcast"></i> Launch Year</strong></div>
                    <div className="row">
                        {launch_year}
                    </div>
                    <div className="heading"><strong><i className="bi bi-award-fill"></i> Successful Launch</strong></div>
                    <div className="col-12 d-grid gap-2 mt-2">
                        <button type="button" className="btn btn-info" onClick={(event) => getYearData(event, true)}>True</button>
                        <button type="button" className="btn btn-info" onClick={(event) => getYearData(event, false)}>False</button>
                    </div>
                    <div className="heading"><strong><i className="bi bi-bookmark-check-fill"></i> Successful Landing</strong></div>
                    <div className="col-12 d-grid gap-2 mt-2">
                        <button type="button" className="btn btn-info" onClick={(event) => getYearData(event, true)}>True</button>
                        <button type="button" className="btn btn-info" onClick={(event) => getYearData(event, false)}>False</button>
                    </div>
                </div>
                <div className="col-sm-1 col-md-10 col-lg-10 col-xl-10 mt-3">
                    <div className="row">
                        <div className="alert alert-primary" role="alert">
                            <strong>Total Results</strong> {allThumbnail.length}
                        </div>
                    </div>
                    <div className="row">
                        {allThumbnail.length === 0 ? (
                            <div className="loader-wrapper">
                                <div className="spinner-border text-primary" role="status">
                                    <span className="visually-hidden">Loading...</span>
                                </div>
                            </div>
                        ) : (
                            getAllThumb
                        )}
                    </div>
                </div>
            </div>
        </div>
    )
}
