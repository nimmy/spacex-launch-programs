import { createStore } from 'redux';
import rootReducer from '../reducers/root.reducer';

const defaultStoreData = {
    add:'nimesh',
    remove: 'dsdd'
}

const store = createStore(rootReducer, defaultStoreData);
 export default store;